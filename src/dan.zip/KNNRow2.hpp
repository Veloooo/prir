#include "Row.hpp"

using namespace std;

class KNNRow2{
public:
	double f1;
	double f2;
	double f3;
	double f4;
	double f5;
	double f6;
	double f7;
	double f8;
};
